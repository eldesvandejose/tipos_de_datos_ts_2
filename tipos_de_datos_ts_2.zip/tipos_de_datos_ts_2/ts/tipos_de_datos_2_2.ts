/* OPERACIONES CON DATOS NUMÉRICOS EN DISTINTAS BASES DE NUMERACIÓN */

/* Declaramos las variables */
let valor_5: number = 350; // Valor decimal
let valor_6: number = 0b1100; // Valor 12 expresado en binario
let valor_7: number = 0o101; // Valor 65 expresado en octal
let valor_8: number = 0xCD; // Valor 205 expresado en hexadecimal
let suma: number = valor_5 + valor_6; // La suma de dos datos en distintas bases.
let producto: number = valor_7 * valor_8; // El producto de valores en distintas bases

/* Las mostramos en consola */
console.log("La variable 'valor_5' vale ", valor_5);
console.log("La variable 'valor_6' vale ", valor_6);
console.log("La variable 'valor_7' vale ", valor_7);
console.log("La variable 'valor_8' vale ", valor_8);
console.log("La suma de ", valor_5, " y ", valor_6, " da ", suma);
console.log("El producto de ", valor_7, " y ", valor_8, " da ", producto);


