"use strict";
/* OPERACIONES CON DATOS NUMÉRICOS EN DISTINTAS BASES DE NUMERACIÓN */
/* Declaramos las variables */
let valor_1 = 350; // Valor decimal
let valor_2 = 0b1100; // Valor 12 expresado en binario
let valor_3 = 0o101; // Valor 65 expresado en octal
let valor_4 = 0xCD; // Valor 205 expresado en hexadecimal
/* Las mostramos en consola */
console.log("La variable 'valor_1' vale ", valor_1);
console.log("La variable 'valor_2' vale ", valor_2);
console.log("La variable 'valor_3' vale ", valor_3);
console.log("La variable 'valor_4' vale ", valor_4);
